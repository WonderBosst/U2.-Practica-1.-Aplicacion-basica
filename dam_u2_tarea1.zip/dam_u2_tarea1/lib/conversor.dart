import 'package:flutter/material.dart';

class Conversor extends StatefulWidget{

  @override
  State<StatefulWidget> createState() {
    return _Conversor();
  }

}

class _Conversor extends State<Conversor>{
  final num1 = TextEditingController();
  final nombre = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Center(
              child: Text("Practica 1")
          ),
          actions: [
      IconButton(
      icon: Icon(Icons.menu),
      onPressed: () {
        showDialog(context: context,
                builder: (BuildContext context){
                  return AlertDialog(
                    title: Text("Acabas de activar el mensaje de la esquina superior derecha:"),
                    content: Text("Buenas tardes"),
                    actions: [
                      TextButton(onPressed: (){
                        Navigator.of(context).pop();
                      },
                          child: Text("ok")
                      )
                    ],
                  );
                });
      },
    )
       ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text("Conversor de decimal a Octal, hexadecimal y binario", style: TextStyle(fontSize: 30,color: Colors.cyan),),
          SizedBox(height: 70,width: 10,),
          Padding(padding: EdgeInsets.all(30),
            child:
            TextField(controller: num1, decoration: InputDecoration(
                labelText: "Numero:"),
            ),
          ),

          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(padding: EdgeInsets.all(5),
                    child: ElevatedButton(onPressed: (){
                      Binario(num1.text);
                    }, child: Text("Binario"))
                ),
                Padding(padding: EdgeInsets.all(5),
                    child: ElevatedButton(onPressed: (){
                      Hexadecimal(num1.text);
                    }, child: Text("Hexadecimal"))
                ),
              ],
            ),
          ),
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(padding: EdgeInsets.all(5),
                    child: ElevatedButton(onPressed: (){
                      Octal(num1.text);
                    }, child: Text("Octal"))
                ),
              ],

            ),
          ),
        ],
      ),

    );
  }
  /////////////////////////////////////////////////////////////////////
  void Binario(String text) {
    //Valor de retorno,identificador parametros
    int n1 = int.parse(text);

  /////////////////////////////////////////////////////////////////////
      String resultado = '';
      int remainder;
      while (n1 > 0) {
        remainder = n1 % 2;
        resultado = '$remainder$resultado';
        n1 = n1 ~/ 2;
      }

   /////////////////////////////////////////////////////////////////////
    showDialog(context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: Text("Resultado:"),
            content: Text("El numero binario es: ${resultado}"),
            actions: [
              TextButton(onPressed: (){
                Navigator.of(context).pop();
              },
                  child: Text("ok")
              )
            ],
          );
        });
  }
    //////////////////////////////////////////////////////////////////////
  void Hexadecimal(String text) {
    //Valor de retorno,identificador parametros
    int n1 = int.parse(text);

    /////////////////////////////////////////////////////////////////////
    String hex = n1.toRadixString(16);
    /////////////////////////////////////////////////////////////////////
    showDialog(context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: Text("Resultado:"),
            content: Text("El numero en hexadecimal es: ${hex}"),
            actions: [
              TextButton(onPressed: (){
                Navigator.of(context).pop();
              },
                  child: Text("ok")
              )
            ],
          );
        });
  }
  ///////////////////////////////////////////////////////////////////////
  void Octal(String text) {
    //Valor de retorno,identificador parametros
    int n1 = int.parse(text);

    /////////////////////////////////////////////////////////////////////
    String octal = n1.toRadixString(8);
    /////////////////////////////////////////////////////////////////////
    showDialog(context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: Text("Resultado:"),
            content: Text("El numero en octal es: ${octal}"),
            actions: [
              TextButton(onPressed: (){
                Navigator.of(context).pop();
              },
                  child: Text("ok")
              )
            ],
          );
        });
  }

}

