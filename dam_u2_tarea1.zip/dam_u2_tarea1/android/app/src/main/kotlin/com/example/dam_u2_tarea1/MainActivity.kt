package com.example.dam_u2_tarea1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
